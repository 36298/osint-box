# OSINT Box

A production-ready, local-first reconnaissance toolkit for Android, built with Flutter.
One app, six modules, zero accounts, zero keys, and a single GitHub Actions workflow that
compiles the release `.apk` for you.

Dark cybersecurity UI: `#0D1117` background · `#161B22` cards · `#00E676` primary · `#00B0FF` secondary.

## Modules

| Module | What it does | Source |
|---|---|---|
| **IP Intelligence** | Live IPv4/IPv6 geolocation — city, region, country, coordinates, ASN, ISP/organization, timezone, postal code, one-tap Maps launch. “My IP” default. | `ipapi.co` (fallback `ipwho.is`) |
| **DNS Recon** | Real DNS-over-HTTPS queries for A, AAAA, MX, TXT, NS and CNAME with TTL values per record. | `dns.google/resolve` |
| **HTTP Analyzer** | Status codes, server banners, manual redirect chains, and missing security headers (HSTS, CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy) with a grade. | Any HTTP/HTTPS host |
| **RDAP Lookup** | Registrar, registration/expiration/last-changed dates, status flags and nameserver count/list. | `rdap.org` |
| **Username Enumeration** | Direct profile links for GitHub, Reddit, Keybase, X, Instagram, TikTok and Medium — one-tap external launch, optional best-effort verification. | Direct links |
| **Crypto Tools** | Offline MD5 / SHA-1 / SHA-256 / SHA-512 generation, bcrypt/MD5/SHA-1/SHA-256/SHA-512/Base64/URL/hex identification, Base64 & URL encodings. | None — 100% on-device |

Every module has: loading and error states with retry, copy-to-clipboard buttons, and
JSON export/share (native share sheet) of the full result.

## Project layout

```
.github/workflows/build.yml   # self-contained CI: Java 17 → Flutter → APK artifact
pubspec.yaml                  # http, url_launcher, crypto, share_plus
lib/
  main.dart                   # MaterialApp + theme
  theme.dart                  # dark cybersecurity palette & ThemeData
  utils/helpers.dart          # validation & formatting
  services/                   # one file per module (models + parsing + HTTP)
  widgets/                    # AppHeader, status views, Pill, CopyButton, JsonShareBar, …
  screens/                    # Dashboard + 6 tool pages
```

## Build it yourself

Prerequisites: [Flutter SDK](https://docs.flutter.dev/get-started/install) (stable),
JDK 17, Android SDK.

```bash
# Android folder is generated (uses flutter create, which preserves lib/ and pubspec.yaml)
flutter create . --org com.osintbox --project-name osint_box --platforms android
flutter pub get
flutter build apk --release
# → build/app/outputs/flutter-apk/app-release.apk
```

## CI (zero local setup)

Push this repository to GitHub. The workflow [.github/workflows/build.yml](.github/workflows/build.yml):

1. checks out the repo (`actions/checkout@v4`)
2. sets up Java 17 (`actions/setup-java@v4`)
3. installs Flutter stable (`subosito/flutter-action@v2`)
4. scaffolds the Android project (`flutter create .`)
5. configures `android.permission.INTERNET` and `<queries>` (Android 11+ URL/share visibility)
6. `flutter pub get`
7. `flutter build apk --release`
8. verifies and uploads `app-release.apk` as a build artifact (`actions/upload-artifact@v4`)

Every push / PR / manual run produces the APK as a downloadable artifact in the run.

## Notes

- Public APIs (ipapi.co, RN/DNS/RDAP) are rate-limited per their respective terms — do not bulk-query.
- The APK is debug-signed by default. For store releases, add a release keystore to the repo secrets.
- This tool is for lawful reconnaissance and your own infrastructure/accounts. Respect terms of service
  and applicable law.
