import 'package:flutter/material.dart';

import 'package:osint_box/theme.dart';
import 'package:osint_box/screens/dashboard_page.dart';

void main() {
  runApp(const OSINTBoxApp());
}

class OSINTBoxApp extends StatelessWidget {
  const OSINTBoxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OSINT Box',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const DashboardPage(),
    );
  }
}
