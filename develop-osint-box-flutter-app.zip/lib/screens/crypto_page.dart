import 'package:flutter/material.dart';

import 'package:osint_box/services/crypto_service.dart';
import 'package:osint_box/theme.dart';
import 'package:osint_box/widgets/app_header.dart';
import 'package:osint_box/widgets/copy_button.dart';
import 'package:osint_box/widgets/json_share_bar.dart';
import 'package:osint_box/widgets/pill.dart';

class CryptoPage extends StatefulWidget {
  const CryptoPage({super.key});

  @override
  State<CryptoPage> createState() => _CryptoPageState();
}

class _CryptoPageState extends State<CryptoPage> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Map<String, dynamic> _exportJson(String input) {
    final hash = CryptoService.identify(input);
    return {
      'input': input,
      'input_length': input.length,
      'identification': hash.toJson(),
      'hashes': {
        'md5': CryptoService.md5(input),
        'sha1': CryptoService.sha1(input),
        'sha256': CryptoService.sha256(input),
        'sha512': CryptoService.sha512(input),
      },
      'encodings': {
        'base64': CryptoService.base64Encode(input),
        'base64_url': CryptoService.base64UrlEncode(input),
        'url_encoded': CryptoService.urlEncode(input),
      },
      'source': 'OSINT Box · offline crypto & hashing',
    };
  }

  @override
  Widget build(BuildContext context) {
    final input = _controller.value.text;
    final trimmed = input.trim();
    final hasContent = trimmed.isNotEmpty;
    final identification = CryptoService.identify(input);
    final md5 = CryptoService.md5(input);
    final sha1 = CryptoService.sha1(input);
    final sha256 = CryptoService.sha256(input);
    final sha512 = CryptoService.sha512(input);
    final base64 = CryptoService.base64Encode(input);
    final base64Url = CryptoService.base64UrlEncode(input);
    final urlEncoded = CryptoService.urlEncode(input);
    final urlDecoded = CryptoService.urlDecode(trimmed);
    final base64Decoded = () {
      try {
        return CryptoService.base64Decode(trimmed);
      } catch (_) {
        return null;
      }
    }();
    final looksLikeHash = identification.looksLikeHash;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            AppHeader(
              title: 'Local Crypto & Hash',
              subtitle: 'Identify, generate & encode — fully offline',
              icon: Icons.vpn_key,
              accent: Accent.red,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 14),
            // Input
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _controller,
                maxLines: 6,
                minLines: 3,
                maxLength: 2048,
                textCapitalization: TextCapitalization.none,
                autocorrect: false,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 13,
                  color: AppColors.textPrimary,
                ),
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  hintText: 'Type or paste anything — plain text, a hash, a Base64 string…',
                  alignLabelWithHint: true,
                  counterText: '',
                  prefixIcon: Icon(Icons.code, size: 18, color: AppColors.textSecondary),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Pill(
                    label: '${input.length} CHARS',
                    color: AppColors.secondary,
                    tint: Accent.blue.tint,
                  ),
                  const SizedBox(width: 10),
                  Pill(
                    label: '${trimmed.isEmpty ? 0 : trimmed.runes.length} RUNES',
                    color: AppColors.textSecondary,
                    tint: AppColors.elevated,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Identification
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'IDENTIFICATION',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.6,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              identification.label,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: looksLikeHash ? AppColors.primary : AppColors.secondary,
                                fontFamily: 'monospace',
                                fontSize: 23,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                          if (looksLikeHash)
                            Pill(
                              label: 'HASH',
                              color: AppColors.primary,
                              tint: Accent.green.tint,
                              icon: Icons.verified,
                            ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        identification.note,
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 12,
                          height: 1.45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            // Hash generator
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SectionCard(
                title: 'HASH GENERATOR',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _ValueRow(label: 'MD5', value: md5, monoSize: 11.5),
                    const _DividerHeader(),
                    _ValueRow(label: 'SHA-1', value: sha1, monoSize: 11.5),
                    const _DividerHeader(),
                    _ValueRow(label: 'SHA-256', value: sha256, monoSize: 11.5),
                    const _DividerHeader(),
                    _ValueRow(label: 'SHA-512', value: sha512, monoSize: 11.5),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            // Encoders
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SectionCard(
                title: 'ENCODERS',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _ValueRow(label: 'Base64', value: base64),
                    const _DividerHeader(),
                    _ValueRow(label: 'Base64 URL', value: base64Url),
                    const _DividerHeader(),
                    _ValueRow(label: 'URL ENCODE', value: urlEncoded),
                    const _DividerHeader(),
                    _ValueRow(
                      label: 'URL DECODE',
                      value: urlDecoded,
                      error: urlDecoded == null ? 'Invalid percent-encoding' : null,
                    ),
                    const _DividerHeader(),
                    _ValueRow(
                      label: 'BASE64 DECODE',
                      value: base64Decoded,
                      error: base64Decoded == null ? 'Invalid Base64' : null,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: JsonShareBar(json: _exportJson(input), subject: 'OSINT Box — Crypto'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.6,
              ),
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _DividerHeader extends StatelessWidget {
  const _DividerHeader();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Divider(height: 1),
    );
  }
}

class _ValueRow extends StatelessWidget {
  final String label;
  final String? value;
  final String? error;
  final double monoSize;

  const _ValueRow({
    required this.label,
    required this.value,
    this.error,
    this.monoSize = 11.5,
  });

  @override
  Widget build(BuildContext context) {
    final v = value;
    final hasError = error != null;
    final hasValue = v != null && v.trim().isNotEmpty;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: 96,
          child: Text(
            label,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.9,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: hasError
              ? Text(
                  error!,
                  style: const TextStyle(color: AppColors.danger, fontSize: 12),
                )
              : LimitedBox(
                  maxHeight: 44,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Text(
                      hasValue ? v! : '—',
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: monoSize,
                        color: hasValue ? AppColors.secondary : AppColors.textSecondary,
                        height: 1.5,
                      ),
                    ),
                  ),
                ),
        ),
        if (hasValue) CopyButton(text: v!, iconOnly: true),
      ],
    );
  }
}
