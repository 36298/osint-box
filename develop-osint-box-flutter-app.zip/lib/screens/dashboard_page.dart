import 'package:flutter/material.dart';

import 'package:osint_box/theme.dart';
import 'package:osint_box/widgets/tool_card.dart';
import 'package:osint_box/screens/ip_page.dart';
import 'package:osint_box/screens/dns_page.dart';
import 'package:osint_box/screens/http_page.dart';
import 'package:osint_box/screens/rdap_page.dart';
import 'package:osint_box/screens/username_page.dart';
import 'package:osint_box/screens/crypto_page.dart';

class _Tool {
  final String title;
  final String description;
  final String badge;
  final IconData icon;
  final Accent accent;
  final Widget page;

  const _Tool({
    required this.title,
    required this.description,
    required this.badge,
    required this.icon,
    required this.accent,
    required this.page,
  });
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  static const _tools = <_Tool>[
    _Tool(
      title: 'IP Intelligence',
      description: 'Live geolocation, ASN, ISP, timezone & coordinates',
      badge: 'LIVE API',
      icon: Icons.public,
      accent: Accent.green,
      page: IpPage(),
    ),
    _Tool(
      title: 'DNS Recon',
      description: 'A / AAAA / MX / TXT / NS / CNAME records via DNS-over-HTTPS',
      badge: 'DNS-over-HTTPS',
      icon: Icons.dns,
      accent: Accent.blue,
      page: DnsPage(),
    ),
    _Tool(
      title: 'HTTP Analyzer',
      description: 'Status, redirects, server banner & security headers',
      badge: 'LIVE API',
      icon: Icons.http,
      accent: Accent.purple,
      page: HttpPage(),
    ),
    _Tool(
      title: 'RDAP Lookup',
      description: 'Registrar, registration & expiration dates, status flags',
      badge: 'RDAP.ORG',
      icon: Icons.domain,
      accent: Accent.warning,
      page: RdapPage(),
    ),
    _Tool(
      title: 'Username Enumeration',
      description: 'Direct profile links & one-tap browser launch',
      badge: 'LIVE API',
      icon: Icons.person,
      accent: Accent.orange,
      page: UsernamePage(),
    ),
    _Tool(
      title: 'Crypto Tools',
      description: 'Local hashing, Base64 / URL encodings, hash ID',
      badge: 'OFFLINE',
      icon: Icons.vpn_key,
      accent: Accent.red,
      page: CryptoPage(),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 30, 20, 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // App wordmark
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Accent.green.tint,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: Accent.green.strong),
                      ),
                      child: const Icon(Icons.radar, color: Accent.green.solid, size: 24),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Text(
                                'OSINT BOX',
                                style: TextStyle(
                                  color: AppColors.textPrimary,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 4,
                                ),
                              ),
                              SizedBox(width: 10),
                              _VersionBadge(),
                            ],
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Local-first reconnaissance toolkit',
                            style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 12.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Status strip
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Accent.green.tint,
                            blurRadius: 8,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 9),
                    const Text(
                      'Live API access · 6 modules · 100% local crypto',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 11.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                // Section header
                Row(
                  children: [
                    const Icon(Icons.grid_view_rounded, size: 14, color: AppColors.textSecondary),
                    const SizedBox(width: 8),
                    const Text(
                      'MODULES',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2.4,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Divider(color: AppColors.border, height: 1),
                    ),
                    const Text(
                      '6',
                      style: TextStyle(color: AppColors.primary, fontSize: 11, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                // Module grid
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.94,
                  ),
                  itemCount: _tools.length,
                  itemBuilder: (context, i) {
                    final t = _tools[i];
                    return ToolCard(
                      title: t.title,
                      description: t.description,
                      badge: t.badge,
                      icon: t.icon,
                      accent: t.accent,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => t.page),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 24),
                // Footer note
                const Text(
                  'All tools query public endpoints directly from the app — results reflect public data at query time. Use responsibly and respect sites’ terms of service before bulk queries.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 10.5, height: 1.5),
                ),
                const SizedBox(height: 16),
                Center(
                  child: Text(
                    'OSINT BOX v1.0.0',
                    style: TextStyle(
                      color: AppColors.border,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _VersionBadge extends StatelessWidget {
  const _VersionBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: Accent.green.tint,
        borderRadius: BorderRadius.circular(7),
        border: Border.all(color: Accent.green.strong),
      ),
      child: const Text(
        'v1.0.0',
        style: TextStyle(
          color: AppColors.primary,
          fontSize: 10,
          fontWeight: FontWeight.w800,
          letterSpacing: 1,
        ),
      ),
    );
  }
}
