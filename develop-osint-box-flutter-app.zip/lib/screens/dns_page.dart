import 'package:flutter/material.dart';

import 'package:osint_box/services/dns_service.dart';
import 'package:osint_box/theme.dart';
import 'package:osint_box/widgets/app_header.dart';
import 'package:osint_box/widgets/copy_button.dart';
import 'package:osint_box/widgets/info_row.dart';
import 'package:osint_box/widgets/json_share_bar.dart';
import 'package:osint_box/widgets/pill.dart';
import 'package:osint_box/widgets/status_views.dart';

class DnsPage extends StatefulWidget {
  const DnsPage({super.key});

  @override
  State<DnsPage> createState() => _DnsPageState();
}

enum _Status { idle, loading, success, error }

class _DnsPageState extends State<DnsPage> {
  final _controller = TextEditingController();
  _Status _status = _Status.idle;
  DnsLookupResult? _result;
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final input = _controller.text;
    setState(() {
      _status = _Status.loading;
      _error = null;
      _result = null;
    });
    try {
      final result = await DnsService().lookup(input);
      if (!mounted) return;
      setState(() {
        _status = _Status.success;
        _result = result;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _status = _Status.error;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            AppHeader(
              title: 'DNS & Subdomain Recon',
              subtitle: 'A / AAAA / MX / TXT / NS / CNAME · DNS-over-HTTPS',
              icon: Icons.dns,
              accent: Accent.blue,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      textCapitalization: TextCapitalization.none,
                      autocorrect: false,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _run(),
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'example.com',
                        prefixIcon: Icon(Icons.language, size: 18),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _run,
                    child: const Icon(Icons.search, size: 19),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(48, 46), padding: EdgeInsets.zero),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            if (_status == _Status.loading)
              const LoadingState(label: 'Querying dns.google (DoH)…')
            else if (_status == _Status.error)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ErrorState(message: _error ?? 'Unknown error', onRetry: _run),
              )
            else if (_status == _Status.success && _result != null)
              _DnsResult(result: _result!)
            else
              const EmptyState(
                message: 'Resolve DNS records',
                hint: 'Enter a domain and press the search button',
              ),
          ],
        ),
      ),
    );
  }
}

class _DnsResult extends StatelessWidget {
  final DnsLookupResult result;

  const _DnsResult({required this.result});

  @override
  Widget build(BuildContext context) {
    final answering = result.answeringTypes;
    final errors = result.types.where((t) => t.error != null).toList();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          result.domain,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            color: AppColors.textPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      CopyButton(text: result.domain, iconOnly: true),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Pill(
                        label: '${answering.length} / 6 TYPES ANSWERED',
                        color: answering.isEmpty ? AppColors.warning : AppColors.primary,
                        tint: answering.isEmpty ? Accent.orange.tint : Accent.green.tint,
                      ),
                      Pill(
                        label: 'DoH',
                        color: AppColors.secondary,
                        tint: Accent.blue.tint,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          ...result.types.map((t) => _TypeCard(typeResult: t)),
          if (errors.isNotEmpty) ...[
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    const Icon(Icons.warning_amber_outlined, color: AppColors.warning, size: 16),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '${errors.length} type(s) failed: ${errors.map((e) => e.type).join(', ')}',
                        style: const TextStyle(color: AppColors.warning, fontSize: 11.5),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          JsonShareBar(json: result.toJson(), subject: 'OSINT Box — DNS ${result.domain}'),
        ],
      ),
    );
  }
}

class _TypeCard extends StatelessWidget {
  final DnsTypeResult typeResult;

  const _TypeCard({required this.typeResult});

  @override
  Widget build(BuildContext context) {
    final records = typeResult.records;
    final hasError = typeResult.error != null;
    final color = hasError ? AppColors.danger : AppColors.secondary;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 52,
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.elevated,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.borderStrong),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      typeResult.type,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w800,
                        fontSize: 11,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    hasError
                        ? typeResult.error!
                        : records.isEmpty
                            ? 'No records returned'
                            : '${records.length} record${records.length == 1 ? '' : 's'}',
                    style: TextStyle(
                      color: hasError ? AppColors.danger : AppColors.textSecondary,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              if (records.isNotEmpty) ...[
                const Divider(height: 20),
                ...records.map((r) => _RecordRow(record: r)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _RecordRow extends StatelessWidget {
  final DnsRecord record;

  const _RecordRow({required this.record});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              record.data,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: const TextStyle(
                fontFamily: 'monospace',
                color: AppColors.textPrimary,
                fontSize: 11.5,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: BoxDecoration(
              color: AppColors.elevated,
              borderRadius: BorderRadius.circular(7),
              border: Border.all(color: AppColors.border),
            ),
            child: Text(
              'TTL ${record.ttl}s',
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 10,
                fontFamily: 'monospace',
              ),
            ),
          ),
          const SizedBox(width: 4),
          CopyButton(text: record.data, iconOnly: true),
        ],
      ),
    );
  }
}
