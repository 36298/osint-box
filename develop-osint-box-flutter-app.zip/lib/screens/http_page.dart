import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:osint_box/services/http_service.dart';
import 'package:osint_box/theme.dart';
import 'package:osint_box/widgets/app_header.dart';
import 'package:osint_box/widgets/copy_button.dart';
import 'package:osint_box/widgets/info_row.dart';
import 'package:osint_box/widgets/json_share_bar.dart';
import 'package:osint_box/widgets/pill.dart';
import 'package:osint_box/widgets/status_views.dart';

class HttpPage extends StatefulWidget {
  const HttpPage({super.key});

  @override
  State<HttpPage> createState() => _HttpPageState();
}

enum _Status { idle, loading, success, error }

class _HttpPageState extends State<HttpPage> {
  final _controller = TextEditingController();
  _Status _status = _Status.idle;
  HttpCheckResult? _result;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final input = _controller.text;
    setState(() {
      _status = _Status.loading;
      _result = null;
    });
    final result = await HttpAnalyzerService().analyze(input);
    if (!mounted) return;
    setState(() {
      _result = result;
      _status = result.ok ? _Status.success : _Status.error;
    });
  }

  Future<void> _launch(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open URL')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            AppHeader(
              title: 'HTTP Security Analyzer',
              subtitle: 'Status, redirects, server banner & headers',
              icon: Icons.http,
              accent: Accent.purple,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      textCapitalization: TextCapitalization.none,
                      autocorrect: false,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _run(),
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 13.5,
                        color: AppColors.textPrimary,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'example.com  or  https://example.com/path',
                        prefixIcon: Icon(Icons.track_changes, size: 18),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _run,
                    child: const Icon(Icons.search, size: 19),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(48, 46), padding: EdgeInsets.zero),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            if (_status == _Status.loading)
              const LoadingState(label: 'Fetching response…')
            else if (_status == _Status.error)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ErrorState(
                  message: _result?.error ?? 'Unknown error',
                  onRetry: _run,
                ),
              )
            else if (_status == _Status.success && _result != null)
              _ResultView(result: _result!, onLaunch: _launch)
            else
              const EmptyState(
                message: 'Analyze a URL',
                hint: 'Enter a hostname — we check headers, redirects & banners',
              ),
          ],
        ),
      ),
    );
  }
}

class _ResultView extends StatelessWidget {
  final HttpCheckResult result;
  final Future<void> Function(String url) onLaunch;

  const _ResultView({required this.result, required this.onLaunch});

  Color _statusColor(int? code) {
    if (code == null) return AppColors.danger;
    if (code < 300) return AppColors.primary;
    if (code < 400) return AppColors.secondary;
    if (code < 500) return AppColors.warning;
    return AppColors.danger;
  }

  Accent _statusAccent(int? code) {
    if (code == null) return Accent.red;
    if (code < 300) return Accent.green;
    if (code < 400) return Accent.blue;
    if (code < 500) return Accent.warning;
    return Accent.red;
  }

  Color _gradeColor(String grade) {
    switch (grade) {
      case 'A': return AppColors.primary;
      case 'B': return AppColors.secondary;
      case 'C': return AppColors.warning;
      case 'D': return AppColors.orange;
      default: return AppColors.danger;
    }
  }

  Accent _gradeAccent(String grade) {
    switch (grade) {
      case 'A': return Accent.green;
      case 'B': return Accent.blue;
      case 'C': return Accent.warning;
      case 'D': return Accent.orange;
      default: return Accent.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColor(result.statusCode);
    final statusAccent = _statusAccent(result.statusCode);
    final gradeColor = _gradeColor(result.grade);
    final gradeAccent = _gradeAccent(result.grade);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Status banner
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Pill(
                        label: result.statusCode != null ? 'HTTP ${result.statusCode}' : 'ERROR',
                        color: statusColor,
                        tint: statusAccent.tint,
                      ),
                      const Spacer(),
                      Pill(label: '${result.durationMs} ms', color: AppColors.textSecondary, tint: AppColors.elevated),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          result.finalUrl ?? result.requestedUrl,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            color: AppColors.secondary,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      CopyButton(text: result.finalUrl ?? result.requestedUrl, iconOnly: true),
                      IconButton(
                        tooltip: 'Open in browser',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.open_in_new, size: 15),
                        color: AppColors.textSecondary,
                        onPressed: () => onLaunch(result.finalUrl ?? result.requestedUrl),
                        constraints: const BoxConstraints(minWidth: 30, minHeight: 30),
                        padding: EdgeInsets.zero,
                      ),
                    ],
                  ),
                  const Divider(height: 22),
                  InfoRow(label: 'Method', value: result.methodUsed, mono: true),
                  InfoRow(label: 'Redirects', value: result.redirectCount == 0 ? 'None' : '${result.redirectCount}', mono: true),
                  InfoRow(label: 'Server banner', value: result.server, mono: true),
                  InfoRow(label: 'Content-Type', value: result.contentType, mono: true),
                  InfoRow(label: 'Content-Length', value: result.contentLength, mono: true),
                ],
              ),
            ),
          ),
          if (result.redirects.isNotEmpty) ...[
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'REDIRECT CHAIN',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.6,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ...result.redirects.asMap().entries.map((entry) {
                      final i = entry.key + 1;
                      final hop = entry.value;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Accent.blue.tint,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                '${hop.statusCode}',
                                style: const TextStyle(
                                  color: AppColors.secondary,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'monospace',
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '$i. ${hop.location ?? '(no location)'}',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 11,
                                  fontFamily: 'monospace',
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          // Security headers
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        'SECURITY HEADERS',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.6,
                        ),
                      ),
                      const Spacer(),
                      Pill(
                        label: 'GRADE ${result.grade}',
                        color: gradeColor,
                        tint: gradeAccent.tint,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ...result.observations.map((o) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    o.name,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style: const TextStyle(
                                      color: AppColors.textSecondary,
                                      fontSize: 10.5,
                                      fontFamily: 'monospace',
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    o.present ? (o.value ?? '—') : 'Not set',
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 3,
                                    style: TextStyle(
                                      color: o.present ? AppColors.textPrimary : AppColors.danger,
                                      fontSize: 11.5,
                                      fontFamily: o.present ? 'monospace' : null,
                                      height: 1.4,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Pill(
                              label: o.present ? 'OK' : 'MISSING',
                              color: o.present ? AppColors.primary : AppColors.danger,
                              tint: o.present ? Accent.green.tint : Accent.red.tint,
                            ),
                          ],
                        ),
                      )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          JsonShareBar(json: result.toJson(), subject: 'OSINT Box — HTTP ${result.finalUrl ?? result.requestedUrl}'),
        ],
      ),
    );
  }
}
