import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:osint_box/services/ip_service.dart';
import 'package:osint_box/theme.dart';
import 'package:osint_box/widgets/app_header.dart';
import 'package:osint_box/widgets/copy_button.dart';
import 'package:osint_box/widgets/info_row.dart';
import 'package:osint_box/widgets/json_share_bar.dart';
import 'package:osint_box/widgets/pill.dart';
import 'package:osint_box/widgets/status_views.dart';

class IpPage extends StatefulWidget {
  const IpPage({super.key});

  @override
  State<IpPage> createState() => _IpPageState();
}

enum _Status { idle, loading, success, error }

class _IpPageState extends State<IpPage> {
  final _controller = TextEditingController();
  _Status _status = _Status.loading;
  IpInfo? _info;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch(null); // "My IP" default option
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _fetch(String? ip) async {
    setState(() {
      _status = _Status.loading;
      _error = null;
      _info = null;
    });
    try {
      final info = await IpService().fetch(ip);
      if (!mounted) return;
      setState(() {
        _status = _Status.success;
        _info = info;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _status = _Status.error;
        _error = e is IpLookupException ? e.message : e.toString();
      });
    }
  }

  Future<void> _launchMaps() async {
    final i = _info;
    if (i == null || i.latitude == null || i.longitude == null) return;
    final uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=${i.latitude},${i.longitude}',
    );
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Maps')),
      );
    }
  }

  String? get _country {
    final i = _info;
    if (i == null) return null;
    if (i.countryName != null && i.countryCode != null) {
      return '${i.countryName} (${i.countryCode})';
    }
    return i.countryName ?? i.countryCode;
  }

  String? get _coordinates {
    final i = _info;
    if (i == null || i.latitude == null || i.longitude == null) return null;
    return '${i.latitude!.toStringAsFixed(4)}, ${i.longitude!.toStringAsFixed(4)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            AppHeader(
              title: 'IP Intelligence',
              subtitle: 'Live geolocation, ASN & ISP lookup',
              icon: Icons.public,
              accent: Accent.green,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 16),
            // Input row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.none,
                      autocorrect: false,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _fetch(_controller.text),
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'Enter IPv4 / IPv6  (leave empty for My IP)',
                        prefixIcon: Icon(Icons.public, size: 18),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: () => _fetch(_controller.text),
                    child: const Icon(Icons.search, size: 19),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(48, 46), padding: EdgeInsets.zero),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      _controller.clear();
                      _fetch(null);
                    },
                    icon: const Icon(Icons.my_location, size: 15),
                    label: const Text('My IP'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 38),
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(width: 10),
                    Flexible(
                      child: Text(
                        'providers unavailable',
                        style: const TextStyle(color: AppColors.danger, fontSize: 11),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 14),
            // Results
            if (_status == _Status.loading)
              const LoadingState(label: 'Querying geolocation endpoints…')
            else if (_status == _Status.error)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ErrorState(
                  message: _error ?? 'Unknown error',
                  onRetry: () => _fetch(_controller.text.trim().isEmpty ? null : _controller.text),
                ),
              )
            else if (_status == _Status.success && _info != null)
              _IpResult(
                info: _info!,
                country: _country,
                coordinates: _coordinates,
                onLaunchMaps: _launchMaps,
              )
            else
              const EmptyState(
                message: 'Nothing loaded yet',
                hint: 'Enter an IP or press My IP',
              ),
          ],
        ),
      ),
    );
  }
}

class _IpResult extends StatelessWidget {
  final IpInfo info;
  final String? country;
  final String? coordinates;
  final VoidCallback onLaunchMaps;

  const _IpResult({
    required this.info,
    required this.country,
    required this.coordinates,
    required this.onLaunchMaps,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            clipBehavior: Clip.antiAlias,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        'PUBLIC IP',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.6,
                        ),
                      ),
                      const Spacer(),
                      Pill(label: 'LIVE', color: AppColors.primary, tint: Accent.green.tint),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          info.ip,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 21,
                            fontWeight: FontWeight.w700,
                            color: AppColors.secondary,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                      CopyButton(text: info.ip, iconOnly: true),
                    ],
                  ),
                  const Divider(height: 28),
                  InfoRow(label: 'City', value: info.city),
                  InfoRow(label: 'Region / State', value: info.region),
                  InfoRow(label: 'Country', value: country),
                  InfoRow(label: 'Coordinates', value: coordinates, mono: true),
                  InfoRow(label: 'ASN', value: info.asn, mono: true),
                  InfoRow(label: 'Organization', value: info.organization),
                  InfoRow(label: 'Timezone', value: info.timezone, mono: true),
                  InfoRow(label: 'Postal code', value: info.postalCode, mono: true),
                  if (coordinates != null) ...[
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: onLaunchMaps,
                        icon: const Icon(Icons.map, size: 16),
                        label: const Text('Open in Maps'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.elevated,
                          foregroundColor: AppColors.secondary,
                          side: const BorderSide(color: AppColors.borderStrong),
                          elevation: 0,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                'Source: ${info.provider}',
                style: TextStyle(
                  color: AppColors.border,
                  fontSize: 11,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
            ],
          ),
          const SizedBox(height: 6),
          JsonShareBar(json: info.toJson(), subject: 'OSINT Box — IP Intelligence'),
        ],
      ),
    );
  }
}
