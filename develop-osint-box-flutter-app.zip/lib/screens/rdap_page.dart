import 'package:flutter/material.dart';

import 'package:osint_box/services/rdap_service.dart';
import 'package:osint_box/theme.dart';
import 'package:osint_box/utils/helpers.dart';
import 'package:osint_box/widgets/app_header.dart';
import 'package:osint_box/widgets/copy_button.dart';
import 'package:osint_box/widgets/info_row.dart';
import 'package:osint_box/widgets/json_share_bar.dart';
import 'package:osint_box/widgets/pill.dart';
import 'package:osint_box/widgets/status_views.dart';

class RdapPage extends StatefulWidget {
  const RdapPage({super.key});

  @override
  State<RdapPage> createState() => _RdapPageState();
}

enum _Status { idle, loading, success, error }

class _RdapPageState extends State<RdapPage> {
  final _controller = TextEditingController();
  _Status _status = _Status.idle;
  RdapResult? _result;
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final input = _controller.text;
    setState(() {
      _status = _Status.loading;
      _error = null;
      _result = null;
    });
    try {
      final result = await RdapService().lookup(input);
      if (!mounted) return;
      setState(() {
        _status = _Status.success;
        _result = result;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _status = _Status.error;
        _error = e is RdapLookupException ? e.message : e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            AppHeader(
              title: 'RDAP Domain Lookup',
              subtitle: 'Registrar, dates & status flags via rdap.org',
              icon: Icons.domain,
              accent: Accent.warning,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      textCapitalization: TextCapitalization.none,
                      autocorrect: false,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _run(),
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'example.com',
                        prefixIcon: Icon(Icons.domain, size: 18),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _run,
                    child: const Icon(Icons.search, size: 19),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(48, 46), padding: EdgeInsets.zero),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            if (_status == _Status.loading)
              const LoadingState(label: 'Querying rdap.org…')
            else if (_status == _Status.error)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ErrorState(message: _error ?? 'Unknown error', onRetry: _run),
              )
            else if (_status == _Status.success && _result != null)
              _ResultView(result: _result!)
            else
              const EmptyState(
                message: 'Query an RDAP record',
                hint: 'Enter a hostname — expiry, registrar & flags',
              ),
          ],
        ),
      ),
    );
  }
}

class _ResultView extends StatelessWidget {
  final RdapResult result;

  const _ResultView({required this.result});

  @override
  Widget build(BuildContext context) {
    final expired = result.isExpired;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Text(
                        'DOMAIN',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.6,
                        ),
                      ),
                      const Spacer(),
                      Pill(
                        label: expired ? 'EXPIRED' : 'ACTIVE',
                        color: expired ? AppColors.danger : AppColors.primary,
                        tint: expired ? Accent.red.tint : Accent.green.tint,
                        icon: expired ? Icons.cancel_outlined : Icons.check_circle_outline,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          result.domain,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                      CopyButton(text: result.domain, iconOnly: true),
                    ],
                  ),
                  const Divider(height: 24),
                  InfoRow(label: 'Registrar', value: result.registrar, mono: true),
                  InfoRow(label: 'Registrar handle', value: result.registrarHandle, mono: true),
                  InfoRow(label: 'Registration', value: formatDate(result.registrationDate), mono: true),
                  InfoRow(
                    label: 'Expiration',
                    value: formatDate(result.expirationDate),
                    mono: true,
                  ),
                  InfoRow(label: 'Last changed', value: formatDate(result.lastChangedDate), mono: true),
                  InfoRow(label: 'Nameservers', value: result.nameserverCount > 0 ? '${result.nameserverCount}' : null),
                ],
              ),
            ),
          ),
          if (result.nameservers.isNotEmpty) ...[
            const SizedBox(height: 12),
            _SectionCard(
              title: 'NAMESERVERS (shown first 4)',
              child: Column(
                children: result.nameservers
                    .map((ns) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            children: [
                              const Icon(Icons.dns, size: 13, color: AppColors.textSecondary),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  ns,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontFamily: 'monospace',
                                    fontSize: 12,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                              ),
                              CopyButton(text: ns, iconOnly: true),
                            ],
                          ),
                        ))
                    .toList(),
              ),
            ),
          ],
          if (result.statusFlags.isNotEmpty) ...[
            const SizedBox(height: 12),
            _SectionCard(
              title: 'STATUS FLAGS',
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: result.statusFlags
                    .map((f) => Pill(
                          label: f.toUpperCase(),
                          color: AppColors.textSecondary,
                          tint: AppColors.elevated,
                        ))
                    .toList(),
              ),
            ),
          ],
          const SizedBox(height: 12),
          JsonShareBar(json: result.toJson(), subject: 'OSINT Box — RDAP ${result.domain}'),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.6,
              ),
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}
