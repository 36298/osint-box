import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:osint_box/services/username_service.dart';
import 'package:osint_box/theme.dart';
import 'package:osint_box/utils/helpers.dart';
import 'package:osint_box/widgets/app_header.dart';
import 'package:osint_box/widgets/copy_button.dart';
import 'package:osint_box/widgets/json_share_bar.dart';
import 'package:osint_box/widgets/pill.dart';
import 'package:osint_box/widgets/status_views.dart';

class UsernamePage extends StatefulWidget {
  const UsernamePage({super.key});

  @override
  State<UsernamePage> createState() => _UsernamePageState();
}

enum _Status { idle, success, error }

class _UsernamePageState extends State<UsernamePage> {
  final _controller = TextEditingController();
  _Status _status = _Status.idle;
  String? _error;
  List<PlatformLink> _links = const [];
  Map<String, PlatformCheck> _checks = const {};
  bool _verifying = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _generate() {
    final input = _controller.text.trim();
    if (!isValidUsername(input)) {
      setState(() {
        _status = _Status.error;
        _error = 'Enter a valid username (letters, digits, . _ -)';
        _links = const [];
        _checks = const {};
      });
      return;
    }
    setState(() {
      _status = _Status.success;
      _error = null;
      _links = UsernameService.links(input);
      _checks = const {};
    });
  }

  Future<void> _verify() async {
    if (_links.isEmpty || _verifying) return;
    setState(() => _verifying = true);
    setState(() => _checks = const {});
    for (final link in _links) {
      if (!mounted) return;
      setState(() {
        _checks = {..._checks, link.platform: _checking(link.platform)};
      });
      final check = await UsernameService.checkOne(link.platform, link.url);
      if (!mounted) return;
      setState(() {
        _checks = {..._checks, link.platform: check};
      });
    }
    if (!mounted) return;
    setState(() => _verifying = false);
  }

  PlatformCheck _checking(String platform) =>
      PlatformCheck(platform: platform, statusCode: null, note: 'Checking…');

  Future<void> _launch(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open link')),
      );
    }
  }

  Map<String, dynamic> _exportJson() {
    return {
      'username': _controller.text.trim(),
      'links': _links.map((l) => {
            ...l.toJson(),
            'check': _checks[l.platform]?.toJson(),
          }).toList(),
      'source': 'OSINT Box · username enumeration',
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 32),
          children: [
            AppHeader(
              title: 'Username Enumeration',
              subtitle: 'Direct links across developer & social platforms',
              icon: Icons.person,
              accent: Accent.orange,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      textCapitalization: TextCapitalization.none,
                      autocorrect: false,
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _generate(),
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'username',
                        prefixIcon: Icon(Icons.alternate_email, size: 18),
                        counterText: '',
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _generate,
                    child: const Icon(Icons.search, size: 19),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(48, 46), padding: EdgeInsets.zero),
                  ),
                ],
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  _error!,
                  style: const TextStyle(color: AppColors.danger, fontSize: 11.5),
                ),
              ),
            ],
            if (_status == _Status.success) ...[
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Pill(
                      label: '${_links.length} PLATFORMS',
                      color: AppColors.secondary,
                      tint: Accent.blue.tint,
                    ),
                    const Spacer(),
                    OutlinedButton.icon(
                      onPressed: _verifying ? null : _verify,
                      icon: _verifying
                          ? const SizedBox(
                              width: 13,
                              height: 13,
                              child: CircularProgressIndicator(strokeWidth: 2.2),
                            )
                          : const Icon(Icons.verified, size: 15),
                      label: Text(_verifying ? 'Verifying…' : 'Verify'),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(0, 38),
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              ..._links.map((link) => _PlatformCard(
                    link: link,
                    check: _checks[link.platform],
                    onLaunch: () => _launch(link.url),
                  )),
              const SizedBox(height: 4),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Verification is best-effort: some profiles block HEAD/GET requests or render client-side. Treat 403/404 as inconclusive, not a verdict.',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 10.5, height: 1.5),
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: JsonShareBar(json: _exportJson(), subject: 'OSINT Box — Username ${_controller.text.trim()}'),
              ),
            ]
            else if (_status == _Status.error)
              const EmptyState(
                message: 'Enter a username',
                hint: 'Generate direct profile links in seconds',
              ),
            if (_status == _Status.idle && _links.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 18),
                child: EmptyState(
                  message: 'No username to analyze yet',
                  hint: 'Type a username and press enter',
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _PlatformCard extends StatelessWidget {
  final PlatformLink link;
  final PlatformCheck? check;
  final VoidCallback onLaunch;

  const _PlatformCard({
    required this.link,
    this.check,
    required this.onLaunch,
  });

  @override
  Widget build(BuildContext context) {
    final accent = _accentFor(link.platform);
    final statusColor = check != null
        ? (check!.statusCode == null
            ? AppColors.textSecondary
            : check!.statusCode! == 404
                ? AppColors.danger
                : check!.statusCode! >= 200 && check!.statusCode! < 400
                    ? AppColors.primary
                    : AppColors.warning)
        : AppColors.textSecondary;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: accent.tint,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accent.strong),
                ),
                child: Center(
                  child: Text(
                    _initial(link.platform),
                    style: TextStyle(
                      color: accent.solid,
                      fontWeight: FontWeight.w900,
                      fontSize: 19,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          link.platform,
                          style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (check != null)
                          Flexible(
                            child: Text(
                              check!.note,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                              style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.w600),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      link.handle,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 11.5,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
              CopyButton(text: link.url, iconOnly: true),
              const SizedBox(width: 2),
              IconButton(
                tooltip: 'Open in browser',
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.open_in_new, size: 16),
                color: accent.solid,
                onPressed: onLaunch,
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                padding: EdgeInsets.zero,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Accent _accentFor(String platform) {
    switch (platform) {
      case 'GitHub': return Accent.green;
      case 'Reddit': return Accent.orange;
      case 'Keybase': return Accent.blue;
      case 'X': return Accent.blue;
      case 'Instagram': return Accent.purple;
      case 'TikTok': return Accent.warning;
      case 'Medium': return Accent.green;
      default: return Accent.blue;
    }
  }

  String _initial(String platform) {
    if (platform.isEmpty) return '?';
    return platform.substring(0, 1).toUpperCase();
  }

}
