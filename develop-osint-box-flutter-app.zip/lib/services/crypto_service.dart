import 'dart:convert';

import 'package:crypto/crypto.dart';

/// Result of identifying an unknown hash/opaque string.
class HashIdentification {
  final String label;
  final String note;
  final bool looksLikeHash;

  const HashIdentification({
    required this.label,
    required this.note,
    required this.looksLikeHash,
  });

  Map<String, dynamic> toJson() => {
        'label': label,
        'note': note,
        'looks_like_hash': looksLikeHash,
      };
}

/// All cryptographic primitives and encodings used by the Crypto tab.
/// Entirely offline — no network, no keys.
class CryptoService {
  static const _bcryptRegex = RegExp(r'^\$2(?:a|b|x|y)\$[0-9]{2}\$.{53}$');
  static const _hex32 = RegExp(r'^[0-9a-fA-F]{32}$');
  static const _hex40 = RegExp(r'^[0-9a-fA-F]{40}$');
  static const _hex64 = RegExp(r'^[0-9a-fA-F]{64}$');
  static const _hex128 = RegExp(r'^[0-9a-fA-F]{128}$');
  static const _hexAny = RegExp(r'^[0-9a-fA-F]+$');

  static String md5(String input) => md5.convert(utf8.encode(input)).toString();

  static String sha1(String input) => sha1.convert(utf8.encode(input)).toString();

  static String sha256(String input) => sha256.convert(utf8.encode(input)).toString();

  static String sha512(String input) => sha512.convert(utf8.encode(input)).toString();

  static String base64Encode(String input) => base64.encode(utf8.encode(input));

  static String base64Decode(String input) => utf8.decode(base64.decode(input), allowMalformed: true);

  static String base64UrlEncode(String input) {
    return base64
        .encode(utf8.encode(input))
        .replaceAll('+', '-')
        .replaceAll('/', '_')
        .replaceAll('=', '');
  }

  static String urlEncode(String input) => Uri.encodeQueryComponent(input);

  static String? urlDecode(String input) {
    try {
      return Uri.decodeQueryComponent(input);
    } catch (_) {
      return null;
    }
  }

  /// Identifies the kind of a hash/opaque string by length, regex and decoding.
  static HashIdentification identify(String raw) {
    final input = raw.trim();
    if (input.isEmpty) {
      return const HashIdentification(
        label: 'Empty input',
        note: 'Type some text to analyze.',
        looksLikeHash: false,
      );
    }
    if (_bcryptRegex.hasMatch(input)) {
      return const HashIdentification(
        label: 'bcrypt',
        note: '$2a/$2b/$2x/$2y — 60-char bcrypt hash (cost + salt + digest)',
        looksLikeHash: true,
      );
    }
    if (_hex32.hasMatch(input)) {
      return const HashIdentification(
        label: 'MD5',
        note: '32-char hex — MD5 digest',
        looksLikeHash: true,
      );
    }
    if (_hex40.hasMatch(input)) {
      return const HashIdentification(
        label: 'SHA-1',
        note: '40-char hex — SHA-1 digest',
        looksLikeHash: true,
      );
    }
    if (_hex64.hasMatch(input)) {
      return const HashIdentification(
        label: 'SHA-256',
        note: '64-char hex — SHA-256 digest',
        looksLikeHash: true,
      );
    }
    if (_hex128.hasMatch(input)) {
      return const HashIdentification(
        label: 'SHA-512',
        note: '128-char hex — SHA-512 digest',
        looksLikeHash: true,
      );
    }
    if (_hexAny.hasMatch(input)) {
      return HashIdentification(
        label: 'Hex string',
        note: 'Hex-encoded data (${input.length} hex chars ≈ ${input.length ~/ 2} raw bytes) — no standard digest matches this length',
        looksLikeHash: false,
      );
    }
    try {
      final decoded = base64.decode(input);
      if (decoded.isNotEmpty && input.length % 4 == 0) {
        return const HashIdentification(
          label: 'Base64',
          note: 'Valid Base64 — decodes successfully',
          looksLikeHash: false,
        );
      }
    } catch (_) {}
    final urlDecoded = urlDecode(input);
    if (urlDecoded != null && urlDecoded != input && urlDecoded.contains(' ')) {
      return const HashIdentification(
        label: 'URL-encoded text',
        note: 'Percent-encoded / query-style string',
        looksLikeHash: false,
      );
    }
    return HashIdentification(
      label: 'Plain text',
      note: 'Not a recognized hash — treat as raw content (${input.length} chars, ${utf8.encode(input).length} bytes)',
      looksLikeHash: false,
    );
  }
}
