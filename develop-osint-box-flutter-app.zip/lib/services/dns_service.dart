import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:osint_box/utils/helpers.dart';

/// One DNS answer record.
class DnsRecord {
  final String type;
  final String data;
  final int ttl;

  const DnsRecord({required this.type, required this.data, required this.ttl});

  Map<String, dynamic> toJson() => {'type': type, 'data': data, 'ttl': ttl};
}

/// Per-type outcome.
class DnsTypeResult {
  final String type;
  final List<DnsRecord> records;
  final String? error;
  final int? responseStatus;

  const DnsTypeResult({
    required this.type,
    required this.records,
    this.error,
    this.responseStatus,
  });

  bool get ok => error == null;

  Map<String, dynamic> toJson() => {
        'type': type,
        'records': records.map((r) => r.toJson()).toList(),
        'error': error,
        'response_status': responseStatus,
      };
}

/// Result of a full DoH query.
class DnsLookupResult {
  final String domain;
  final List<DnsTypeResult> types;
  final DateTime queriedAt;

  const DnsLookupResult({
    required this.domain,
    required this.types,
    required this.queriedAt,
  });

  List<DnsTypeResult> get answeringTypes => types.where((t) => t.records.isNotEmpty).toList();

  Map<String, dynamic> toJson() => {
        'domain': domain,
        'queried_at': queriedAt.toIso8601String(),
        'source': 'dns.google (DoH)',
        'types': types.map((t) => t.toJson()).toList(),
      };
}

/// Queries DNS-over-HTTPS (dns.google/resolve) for A, AAAA, MX, TXT, NS, CNAME.
class DnsService {
  static const _types = ['A', 'AAAA', 'MX', 'TXT', 'NS', 'CNAME'];
  static const _timeout = Duration(seconds: 12);
  static const _userAgent = 'OSINT-Box/1.0 (+https://github.com/osintbox)';

  /// Throws ArgumentError for invalid domains.
  Future<DnsLookupResult> lookup(String domain) async {
    final normalized = normalizeDomain(domain);
    if (!isValidDomain(normalized)) {
      throw const FormatException('Enter a valid hostname (e.g. example.com)');
    }

    final futures = _types.map((t) => _fetchType(normalized, t)).toList();
    final results = await Future.wait(futures);
    return DnsLookupResult(domain: normalized, types: results, queriedAt: DateTime.now());
  }

  Future<DnsTypeResult> _fetchType(String domain, String type) async {
    try {
      final uri = Uri.https('dns.google', '/resolve', {'name': domain, 'type': type});
      final res = await http
          .get(
            uri,
            headers: {
              'User-Agent': _userAgent,
              'Accept': 'application/dns-json',
            },
          )
          .timeout(_timeout);

      if (res.statusCode != 200) {
        return DnsTypeResult(
          type: type,
          records: const [],
          error: 'dns.google HTTP ${res.statusCode}',
          responseStatus: res.statusCode,
        );
      }

      final raw = jsonDecode(utf8.decode(res.bodyBytes)) as Map;
      final status = raw['Status'];
      final statusCode = status is int ? status : int.tryParse(status?.toString() ?? '');
      final answers = raw['Answer'];

      final records = <DnsRecord>[];
      if (answers is List) {
        for (final a in answers) {
          if (a is! Map) continue;
          final data = a['data']?.toString();
          if (data == null || data.isEmpty) continue;
          final ttlRaw = a['TTL'];
          final ttl = ttlRaw is int
              ? ttlRaw
              : int.tryParse(ttlRaw?.toString() ?? '') ?? 0;
          final t = (a['type']?.toString() ?? type).toUpperCase();
          records.add(DnsRecord(type: t, data: data, ttl: ttl));
        }
      }

      return DnsTypeResult(
        type: type,
        records: records,
        responseStatus: statusCode,
      );
    } catch (e) {
      return DnsTypeResult(
        type: type,
        records: const [],
        error: e.toString().replaceFirst('Exception: ', ''),
      );
    }
  }
}
