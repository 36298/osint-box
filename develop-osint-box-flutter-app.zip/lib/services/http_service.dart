import 'dart:convert';

import 'package:http/http.dart' as http;

/// One redirect hop captured during analysis.
class RedirectHop {
  final int statusCode;
  final String url;
  final String? location;

  const RedirectHop({required this.statusCode, required this.url, this.location});

  Map<String, dynamic> toJson() => {
        'status_code': statusCode,
        'url': url,
        'location': location,
      };
}

/// Observation for a single checked security header.
class HeaderObservation {
  final String name;
  final bool present;
  final String? value;
  final bool core;

  const HeaderObservation({
    required this.name,
    required this.present,
    required this.value,
    required this.core,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'present': present,
        'value': value,
        'core': core,
      };
}

/// Full analysis result for a single URL.
class HttpCheckResult {
  final String requestedUrl;
  final String? finalUrl;
  final int? statusCode;
  final String? server;
  final String? contentType;
  final String? contentLength;
  final String? methodUsed;
  final int? redirectCount;
  final List<RedirectHop> redirects;
  final Map<String, String> headers;
  final List<HeaderObservation> observations;
  final int durationMs;
  final String grade;
  final String? error;

  const HttpCheckResult({
    required this.requestedUrl,
    this.finalUrl,
    this.statusCode,
    this.server,
    this.contentType,
    this.contentLength,
    this.methodUsed,
    this.redirectCount,
    this.redirects = const [],
    this.headers = const {},
    this.observations = const [],
    this.durationMs = 0,
    this.grade = '?',
    this.error,
  });

  bool get ok => error == null && statusCode != null;

  int get coreMissing =>
      observations.where((o) => o.core && !o.present).length;

  Map<String, dynamic> toJson() => {
        'requested_url': requestedUrl,
        'final_url': finalUrl,
        'status_code': statusCode,
        'server': server,
        'content_type': contentType,
        'content_length': contentLength,
        'method_used': methodUsed,
        'redirect_count': redirectCount,
        'redirects': redirects.map((r) => r.toJson()).toList(),
        'duration_ms': durationMs,
        'grade': grade,
        'security_headers': observations.map((o) => o.toJson()).toList(),
        'headers': headers,
        'error': error,
        'source': 'OSINT Box · HTTP security analyzer',
      };
}

/// Performs live HTTP/HTTPS requests to inspect response status, banners,
/// redirects and security headers.
class HttpAnalyzerService {
  static const _userAgent = 'OSINT-Box/1.0 (+https://github.com/osintbox)';
  static const _timeout = Duration(seconds: 14);
  static const _maxRedirects = 5;

  static const _coreHeaders = [
    'strict-transport-security',
    'content-security-policy',
    'x-frame-options',
    'x-content-type-options',
  ];

  static const _extraHeaders = [
    'referrer-policy',
    'permissions-policy',
  ];

  Future<HttpCheckResult> analyze(String input) async {
    final stopwatch = Stopwatch()..start();
    Uri uri;
    try {
      uri = _normalizeUrl(input);
    } catch (e) {
      return HttpCheckResult(
        requestedUrl: input,
        error: e.toString(),
        durationMs: 0,
      );
    }

    final redirects = <RedirectHop>[];
    final targetUrls = <String>{uri.toString()};
    final headers = <String, String>{};
    String methodUsed = 'HEAD';

    try {
      var current = uri;
      http.Response? response;

      for (var attempt = 0; attempt <= _maxRedirects; attempt++) {
        headers.clear();
        final res = await _send(current, methodUsed);
        response = res;
        headers.addAll(_normalizedHeaders(res.headers));

        final status = res.statusCode;
        final location = res.headers['location'];
        final isRedirect = _isRedirectStatus(status) && location != null && location.trim().isNotEmpty;

        // Follow up to max redirects; stop on loops.
        if (isRedirect && attempt < _maxRedirects) {
          final next = current.resolve(location);
          if (next.host.isEmpty || targetUrls.contains(next.toString())) break;
          targetUrls.add(next.toString());
          redirects.add(RedirectHop(
            statusCode: status,
            url: current.toString(),
            location: location,
          ));
          current = next;
          methodUsed = 'GET'; // some servers fail HEAD on the redirect target
          headers.clear();
          continue;
        }
        break;
      }

      if (response == null) {
        return HttpCheckResult(
          requestedUrl: uri.toString(),
          durationMs: stopwatch.elapsedMilliseconds,
          error: 'No response received',
        );
      }

      final observations = <HeaderObservation>[];
      for (final h in [..._coreHeaders, ..._extraHeaders]) {
        final present = headers.containsKey(h);
        observations.add(HeaderObservation(
          name: h,
          present: present,
          value: present ? headers[h] : null,
          core: _coreHeaders.contains(h),
        ));
      }

      final coreMissing =
          observations.where((o) => o.core && !o.present).length;
      final grade = coreMissing == 0
          ? 'A'
          : coreMissing == 1
              ? 'B'
              : coreMissing == 2
                  ? 'C'
                  : coreMissing == 3
                      ? 'D'
                      : 'F';

      return HttpCheckResult(
        requestedUrl: uri.toString(),
        finalUrl: redirects.isEmpty ? uri.toString() : current.toString(),
        statusCode: response?.statusCode,
        server: headers['server'],
        contentType: headers['content-type'],
        contentLength: headers['content-length'],
        methodUsed: methodUsed,
        redirectCount: redirects.length,
        redirects: redirects,
        headers: headers,
        observations: observations,
        durationMs: stopwatch.elapsedMilliseconds,
        grade: grade,
      );
    } catch (e) {
      return HttpCheckResult(
        requestedUrl: uri.toString(),
        redirects: redirects,
        methodUsed: methodUsed,
        statusCode: null,
        durationMs: stopwatch.elapsedMilliseconds,
        error: _short(e),
      );
    }
  }

  Uri _normalizeUrl(String input) {
    var s = input.trim();
    if (s.isEmpty) throw const FormatException('Enter a URL first');
    if (!s.contains('://')) s = 'https://$s';
    if (!s.startsWith('http://') && !s.startsWith('https://')) {
      throw const FormatException('Use http:// or https://');
    }
    final uri = Uri.parse(s);
    if (uri.host.isEmpty) throw const FormatException('Invalid URL');
    return uri;
  }

  bool _isRedirectStatus(int status) =>
      status == 301 || status == 302 || status == 303 || status == 307 || status == 308;

  Future<http.Response> _send(Uri uri, String method) async {
    final headers = {
      'User-Agent': _userAgent,
      'Accept': '*/*',
      'Accept-Language': 'en-US,en;q=0.9',
    };
    if (method == 'HEAD') {
      final res = await http
          .head(uri, headers: headers)
          .timeout(_timeout);
      // Some hosts answer HEAD with an error; fall back to an actual GET.
      if (res.statusCode == 405 || res.statusCode == 501) {
        return await http.get(uri, headers: headers).timeout(_timeout);
      }
      return res;
    }
    return await http.get(uri, headers: headers).timeout(_timeout);
  }

  Map<String, String> _normalizedHeaders(http.Headers original) {
    final out = <String, String>{};
    original.forEach((name, value) {
      out[name.toLowerCase()] = value;
    });
    return out;
  }

  String _short(Object e) {
    final s = e.toString();
    return s.replaceFirst('TimeoutException: ', 'timed out').replaceFirst('Exception: ', '');
  }
}
