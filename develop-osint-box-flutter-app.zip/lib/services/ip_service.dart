import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:osint_box/utils/helpers.dart';

/// Immutable result of an IP lookup.
class IpInfo {
  final String ip;
  final String? city;
  final String? region;
  final String? countryName;
  final String? countryCode;
  final double? latitude;
  final double? longitude;
  final String? asn;
  final String? organization;
  final String? timezone;
  final String? postalCode;
  final String provider;

  const IpInfo({
    required this.ip,
    this.city,
    this.region,
    this.countryName,
    this.countryCode,
    this.latitude,
    this.longitude,
    this.asn,
    this.organization,
    this.timezone,
    this.postalCode,
    required this.provider,
  });

  Map<String, dynamic> toJson() => {
        'ip': ip,
        'city': city,
        'region': region,
        'country_name': countryName,
        'country_code': countryCode,
        'latitude': latitude,
        'longitude': longitude,
        'asn': asn,
        'organization': organization,
        'timezone': timezone,
        'postal_code': postalCode,
        'provider': provider,
        'source': 'OSINT Box · ip intelligence',
      };
}

/// Thrown when every provider failed.
class IpLookupException implements Exception {
  final String message;

  IpLookupException(this.message);

  @override
  String toString() => message;
}

/// Queries public IP geolocation endpoints with fallback.
///
/// Primary: ipapi.co (simple JSON, no key) — Fallback: ipwho.is.
class IpService {
  static const _timeout = Duration(seconds: 12);
  static const _userAgent = 'OSINT-Box/1.0 (+https://github.com/osintbox)';

  Future<IpInfo> fetch(String? ip) async {
    final target = (ip != null && ip.trim().isNotEmpty) ? ip.trim() : null;
    final errors = <String>[];

    // 1) ipapi.co
    try {
      final url = target == null
          ? 'https://ipapi.co/json/'
          : 'https://ipapi.co/$target/json/';
      final res = await http
          .get(Uri.parse(url), headers: _headers())
          .timeout(_timeout);
      if (res.statusCode == 200) {
        final raw = _decodeMap(utf8.decode(res.bodyBytes));
        final found = _fromIpApi(raw, target);
        if (found != null) return found;
        errors.add('ipapi.co returned an empty/unusable payload');
      } else {
        errors.add('ipapi.co HTTP ${res.statusCode}');
      }
    } catch (e) {
      errors.add('ipapi.co: ${_short(e)}');
    }

    // 2) ipwho.is
    try {
      final url =
          target == null ? 'https://ipwho.is/' : 'https://ipwho.is/$target';
      final res = await http
          .get(Uri.parse(url), headers: _headers())
          .timeout(_timeout);
      if (res.statusCode == 200) {
        final raw = _decodeMap(utf8.decode(res.bodyBytes));
        final found = _fromIpWho(raw, target);
        if (found != null) return found;
        final msg = _asString(raw['message']);
        if (msg != null) {
          errors.add('ipwho.is: $msg');
        } else {
          errors.add('ipwho.is returned an empty/unusable payload');
        }
      } else {
        errors.add('ipwho.is HTTP ${res.statusCode}');
      }
    } catch (e) {
      errors.add('ipwho.is: ${_short(e)}');
    }

    throw IpLookupException(
      errors.isEmpty
          ? 'IP intelligence unavailable from all providers'
          : 'All providers failed — ${errors.join(' · ')}',
    );
  }

  Map<String, String> _headers() => {
        'User-Agent': _userAgent,
        'Accept': 'application/json',
      };

  String _short(Object e) {
    final s = e.toString();
    return s.replaceFirst('Exception: ', '').replaceFirst('TimeoutException: ', 'timeout');
  }

  Map<String, dynamic> _decodeMap(String body) {
    final decoded = jsonDecode(body);
    if (decoded is Map<String, dynamic>) return decoded;
    if (decoded is Map) return Map<String, dynamic>.from(decoded);
    throw const FormatException('expected a JSON object');
  }

  String? _asString(dynamic v) => safeString(v);

  IpInfo? _fromIpApi(Map<String, dynamic> raw, String? target) {
    final ip = _asString(raw['ip']) ?? target;
    if (ip == null || ip.isEmpty) return null;
    return IpInfo(
      ip: ip,
      city: _asString(raw['city']),
      region: _asString(pick(raw, ['region', 'region_name', 'state'], (v) => v as dynamic)),
      countryName: _asString(pick(raw, ['country_name', 'country'], (v) => v as dynamic)),
      countryCode: _asString(pick(raw, ['country_code', 'country_code_iso'], (v) => v as dynamic)),
      latitude: toDouble(pick(raw, ['latitude', 'lat'], (v) => v)),
      longitude: toDouble(pick(raw, ['longitude', 'lng', 'lon'], (v) => v)),
      asn: () {
        final v = pick(raw, ['asn', 'asn_id'], (x) => x);
        if (v == null) return null;
        if (v is num) return 'AS${v.toInt()}';
        return _asString(v);
      }(),
      organization: _asString(
        pick(raw, ['org', 'organization', 'isp', 'company'], (v) => v),
      ),
      timezone: _asString(pick(raw, ['timezone', 'timezone_id'], (v) => v)),
      postalCode: _asString(pick(raw, ['postal', 'postal_code', 'zip'], (v) => v)),
      provider: 'ipapi.co',
    );
  }

  IpInfo? _fromIpWho(Map<String, dynamic> raw, String? target) {
    final success = raw['success'];
    if (success is bool && !success) return null;
    final conn = raw['connection'];
    final connMap = conn is Map ? Map<String, dynamic>.from(conn) : <String, dynamic>{};
    final asnRaw = connMap['asn'] ?? raw['asn'];
    final asn = asnRaw is num ? 'AS${asnRaw.toInt()}' : _asString(asnRaw);

    final tzRaw = connMap['timezone'] ?? raw['timezone'];
    String? tz;
    if (tzRaw is Map) {
      tz = _asString(tzRaw['id']) ?? _asString(tzRaw['name']);
    } else {
      tz = _asString(tzRaw);
    }

    final ip = _asString(raw['ip']) ?? target;
    if (ip == null || ip.isEmpty) return null;

    return IpInfo(
      ip: ip,
      city: _asString(raw['city']),
      region: _asString(raw['region']),
      countryName: _asString(raw['country']),
      countryCode: _asString(raw['country_code']),
      latitude: toDouble(raw['latitude']),
      longitude: toDouble(raw['longitude']),
      asn: asn,
      organization: _asString(connMap['isp']) ?? _asString(connMap['org']),
      timezone: tz,
      postalCode: _asString(raw['postal']) ?? _asString(raw['zip']),
      provider: 'ipwho.is',
    );
  }
}
