import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:osint_box/utils/helpers.dart';

/// Normalized RDAP / WHOIS-style result for a domain.
class RdapResult {
  final String domain;
  final String? registrar;
  final String? registrarHandle;
  final String? registrationDate;
  final String? expirationDate;
  final String? lastChangedDate;
  final List<String> statusFlags;
  final int nameserverCount;
  final List<String> nameservers;
  final Map<String, dynamic> raw;

  const RdapResult({
    required this.domain,
    this.registrar,
    this.registrarHandle,
    this.registrationDate,
    this.expirationDate,
    this.lastChangedDate,
    this.statusFlags = const [],
    this.nameserverCount = 0,
    this.nameservers = const [],
    required this.raw,
  });

  bool get isExpired => isPast(expirationDate);

  Map<String, dynamic> toJson() => {
        'domain': domain,
        'registrar': registrar,
        'registrar_handle': registrarHandle,
        'registration_date': registrationDate,
        'expiration_date': expirationDate,
        'last_changed_date': lastChangedDate,
        'status': statusFlags,
        'nameserver_count': nameserverCount,
        'source': 'rdap.org',
      };
}

/// Thrown when the domain cannot be found or parsed.
class RdapLookupException implements Exception {
  final String message;

  RdapLookupException(this.message);

  @override
  String toString() => message;
}

/// Queries the public RDAP record for a domain (registrar, dates, status).
class RdapService {
  static const _timeout = Duration(seconds: 14);
  static const _userAgent = 'OSINT-Box/1.0 (+https://github.com/osintbox)';

  Future<RdapResult> lookup(String domain) async {
    final normalized = normalizeDomain(domain);
    if (!isValidDomain(normalized)) {
      throw const RdapLookupException('Enter a valid hostname (e.g. example.com)');
    }

    final uri = Uri.https('rdap.org', '/domain/$normalized');
    final res = await http
        .get(
          uri,
          headers: {
            'User-Agent': _userAgent,
            'Accept': 'application/rdap+json, application/json',
          },
        )
        .timeout(_timeout);

    if (res.statusCode == 404 || res.statusCode == 410) {
      throw RdapLookupException('Domain "$normalized" not found (HTTP ${res.statusCode})');
    }
    if (res.statusCode == 400) {
      throw RdapLookupException('Invalid domain name (HTTP 400)');
    }
    if (res.statusCode != 200) {
      throw RdapLookupException('RDAP endpoint returned HTTP ${res.statusCode}');
    }

    final raw = jsonDecode(utf8.decode(res.bodyBytes)) as Map;
    final rawMap = raw is Map<String, dynamic>
        ? raw
        : Map<String, dynamic>.from(raw);

    return _parse(normalized, rawMap);
  }

  RdapResult _parse(String domain, Map<String, dynamic> raw) {
    final events = _extractByAction(raw, ['registration', 'expiration', 'last changed']);

    final statusFlags = <String>[];
    final statusRaw = raw['status'];
    if (statusRaw is List) {
      for (final s in statusRaw) {
        final str = s?.toString();
        if (str != null && str.trim().isNotEmpty) statusFlags.add(str);
      }
    }

    final nameservers = <String>[];
    final nsRaw = raw['nameservers'];
    if (nsRaw is List) {
      for (final n in nsRaw) {
        if (n is Map) {
          final ldh = n['ldhName']?.toString();
          if (ldh != null && ldh.trim().isNotEmpty) {
            final clean = ldh.replaceAll(RegExp(r'\.$'), '').toLowerCase();
            if (clean.isNotEmpty) nameservers.add(clean);
          }
        }
      }
    }

    // Registrar: find the entity whose roles include "registrar".
    String? registrar;
    String? registrarHandle;
    final entitiesRaw = raw['entities'];
    if (entitiesRaw is List) {
      for (final e in entitiesRaw) {
        if (e is! Map) continue;
        final roles = e['roles'];
        final roleList = roles is List ? roles : <dynamic>[];
        if (!roleList.any((r) => r.toString().toLowerCase().contains('registrar'))) continue;
        registrar = (_fromVcard(e['vcardArray']) ?? _asString(e['handle']) ?? _asString(e['publicId']));
        registrarHandle = _asString(e['handle']);
        break;
      }
    }

    return RdapResult(
      domain: domain,
      registrar: registrar,
      registrarHandle: registrarHandle,
      registrationDate: events['registration'],
      expirationDate: events['expiration'],
      lastChangedDate: events['last changed'],
      statusFlags: statusFlags,
      nameserverCount: nameservers.length,
      nameservers: nameservers.take(4).toList(),
      raw: raw,
    );
  }

  Map<String, String?> _extractByAction(Map<String, dynamic> raw, List<String> actions) {
    final out = <String, String?>{};
    for (final a in actions) {
      out[a] = null;
    }
    final eventsRaw = raw['events'];
    if (eventsRaw is! List) return out;
    for (final e in eventsRaw) {
      if (e is! Map) continue;
      final action = e['action']?.toString().toLowerCase().trim();
      if (action == null) continue;
      if (!actions.contains(action)) continue;
      final date = _asString(e['eventDate']);
      if (date != null) out[action] = date;
    }
    return out;
  }

  String? _asString(dynamic v) => safeString(v);

  /// Pulls a displayable name out of a vcardArray-style entity.
  String? _fromVcard(dynamic vcardArray) {
    if (vcardArray is! List || vcardArray.length < 2) return null;
    final items = vcardArray[1];
    if (items is! List) return null;
    for (final item in items) {
      if (item is! List || item.length < 2) continue;
      final key = item[0]?.toString().toLowerCase();
      final value = item[1]?.toString();
      if (value == null || value.trim().isEmpty) continue;
      if (key == 'fn' || key == 'org') return value;
    }
    return null;
  }
}
