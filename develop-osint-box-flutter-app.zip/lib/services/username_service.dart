import 'package:http/http.dart' as http;

import 'package:osint_box/utils/helpers.dart';

/// One generated profile link.
class PlatformLink {
  final String platform;
  final String url;
  final String handle;

  const PlatformLink({
    required this.platform,
    required this.url,
    required this.handle,
  });

  Map<String, dynamic> toJson() => {
        'platform': platform,
        'url': url,
        'handle': handle,
      };
}

/// Verification outcome for a profile URL.
class PlatformCheck {
  final String platform;
  final int? statusCode;
  final String note;

  const PlatformCheck({
    required this.platform,
    required this.statusCode,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'platform': platform,
        'status_code': statusCode,
        'note': note,
      };
}

/// Generates and (optionally) verifies direct reconnaissance links.
class UsernameService {
  static const _timeout = Duration(seconds: 9);
  static const _userAgent = 'OSINT-Box/1.0 (+https://github.com/osintbox)';

  static const _platformBuilders = <String, String>{
    'GitHub': 'https://github.com/{u}',
    'Reddit': 'https://www.reddit.com/user/{u}',
    'Keybase': 'https://keybase.io/{u}',
    'X': 'https://x.com/{u}',
    'Instagram': 'https://www.instagram.com/{u}',
    'TikTok': 'https://www.tiktok.com/@{u}',
    'Medium': 'https://medium.com/@{u}',
  };

  static List<PlatformLink> links(String username) {
    final u = username.trim();
    if (!isValidUsername(u)) return const [];
    return _platformBuilders.entries.map((e) {
      final url = e.value.replaceAll('{u}', u);
      return PlatformLink(platform: e.key, url: url, handle: '@$u');
    }).toList();
  }

  /// Sequential, politely rate-limited verification of profile URLs.
  static Future<Map<String, PlatformCheck>> verify(String username) async {
    final links = links(username);
    final out = <String, PlatformCheck>{};
    for (final link in links) {
      out[link.platform] = await checkOne(link.platform, link.url);
    }
    return out;
  }

  /// Verifies a single profile URL.
  static Future<PlatformCheck> checkOne(String platform, String url) async {
    return _checkOne(PlatformLink(platform: platform, url: url, handle: ''));
  }

  static Future<PlatformCheck> _checkOne(PlatformLink link) async {
    try {
      final res = await http
          .get(
            Uri.parse(link.url),
            headers: {'User-Agent': _userAgent, 'Accept': 'text/html,*/*'},
          )
          .timeout(_timeout);
      final code = res.statusCode;
      String note;
      if (code == 404) {
        note = 'HTTP 404 — not found';
      } else if (code == 403) {
        note = 'HTTP 403 — blocked (not conclusive)';
      } else if (code == 429) {
        note = 'HTTP 429 — rate limited';
      } else if (code >= 200 && code < 400) {
        note = 'HTTP $code — likely reachable';
      } else if (code >= 400) {
        note = 'HTTP $code — restricted/unavailable';
      } else {
        note = 'HTTP $code';
      }
      return PlatformCheck(platform: link.platform, statusCode: code, note: note);
    } catch (e) {
      return PlatformCheck(
        platform: link.platform,
        statusCode: null,
        note: e.toString().contains('timeout')
            ? 'Timed out'
            : 'Unreachable (network)',
      );
    }
  }
}
