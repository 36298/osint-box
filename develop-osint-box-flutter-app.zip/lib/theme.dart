import 'package:flutter/material.dart';

/// Dark cybersecurity palette from the OSINT Box design spec.
class AppColors {
  static const Color background = Color(0xFF0D1117);
  static const Color card = Color(0xFF161B22);
  static const Color elevated = Color(0xFF1C2128);
  static const Color border = Color(0xFF21262D);
  static const Color borderStrong = Color(0xFF30363D);
  static const Color primary = Color(0xFF00E676);
  static const Color secondary = Color(0xFF00B0FF);
  static const Color textPrimary = Color(0xFFE6EDF3);
  static const Color textSecondary = Color(0xFF9BA6B3);
  static const Color danger = Color(0xFFFF5252);
  static const Color warning = Color(0xFFFFC857);
  static const Color purple = Color(0xFFC792EA);
  static const Color orange = Color(0xFFFF9F43);
  static const Color primaryDark = Color(0xFF04170A);
}

/// A module accent plus its translucent tints (border + fill) for chips.
class Accent {
  const Accent(this.solid, this.tint, this.strong);

  final Color solid;
  final Color tint;
  final Color strong;

  static const Accent green = Accent(
    Color(0xFF00E676),
    Color.fromRGBO(0x00, 0xE6, 0x76, 38),
    Color.fromRGBO(0x00, 0xE6, 0x76, 96),
  );
  static const Accent blue = Accent(
    Color(0xFF00B0FF),
    Color.fromRGBO(0x00, 0xB0, 0xFF, 38),
    Color.fromRGBO(0x00, 0xB0, 0xFF, 96),
  );
  static const Accent purple = Accent(
    Color(0xFFC792EA),
    Color.fromRGBO(0xC7, 0x92, 0xEA, 38),
    Color.fromRGBO(0xC7, 0x92, 0xEA, 96),
  );
  static const Accent warning = Accent(
    Color(0xFFFFC857),
    Color.fromRGBO(0xFF, 0xC8, 0x57, 38),
    Color.fromRGBO(0xFF, 0xC8, 0x57, 96),
  );
  static const Accent orange = Accent(
    Color(0xFFFF9F43),
    Color.fromRGBO(0xFF, 0x9F, 0x43, 38),
    Color.fromRGBO(0xFF, 0x9F, 0x43, 96),
  );
  static const Accent red = Accent(
    Color(0xFFFF5252),
    Color.fromRGBO(0xFF, 0x52, 0x52, 38),
    Color.fromRGBO(0xFF, 0x52, 0x52, 96),
  );
}

ThemeData buildAppTheme() {
  const inputRadius = BorderRadius.all(Radius.circular(12));
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    scaffoldBackgroundColor: AppColors.background,
    cardColor: AppColors.card,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.secondary,
      surface: AppColors.card,
      surfaceContainerHighest: AppColors.elevated,
      onPrimary: AppColors.primaryDark,
      onSurface: AppColors.textPrimary,
      onSurfaceVariant: AppColors.textSecondary,
      error: AppColors.danger,
      onError: Colors.white,
    ),
    textTheme: const TextTheme(
      displaySmall: TextStyle(
        color: AppColors.textPrimary,
        fontSize: 30,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.5,
      ),
      headlineSmall: TextStyle(
        color: AppColors.textPrimary,
        fontSize: 20,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.2,
      ),
      titleMedium: TextStyle(
        color: AppColors.textPrimary,
        fontSize: 16,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.2,
      ),
      bodyLarge: TextStyle(color: AppColors.textPrimary, fontSize: 15, height: 1.45),
      bodyMedium: TextStyle(color: AppColors.textPrimary, fontSize: 14, height: 1.45),
      bodySmall: TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.4),
      labelSmall: TextStyle(
        color: AppColors.textSecondary,
        fontSize: 11,
        fontWeight: FontWeight.w600,
        letterSpacing: 1.2,
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.card,
      elevation: 0,
      shadowColor: Colors.black,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColors.border),
      ),
    ),
    dividerTheme: const DividerThemeData(
      color: AppColors.border,
      thickness: 1,
      space: 16,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF10161D),
      isDense: true,
      hintStyle: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
      labelStyle: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      border: OutlineInputBorder(
        borderRadius: inputRadius,
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: inputRadius,
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: inputRadius,
        borderSide: const BorderSide(color: AppColors.primary, width: 1.6),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: inputRadius,
        borderSide: const BorderSide(color: AppColors.danger),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: inputRadius,
        borderSide: const BorderSide(color: AppColors.danger, width: 1.6),
      ),
      errorStyle: const TextStyle(color: AppColors.danger, fontSize: 12),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.primaryDark,
        disabledBackgroundColor: const Color(0xFF1B3325),
        disabledForegroundColor: AppColors.textSecondary,
        elevation: 0,
        minimumSize: const Size.fromHeight(46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.6,
        ),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        backgroundColor: AppColors.elevated,
        foregroundColor: AppColors.secondary,
        side: const BorderSide(color: AppColors.borderStrong),
        minimumSize: const Size.fromHeight(46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: AppColors.textPrimary,
        fontSize: 18,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.4,
      ),
      iconTheme: IconThemeData(color: AppColors.textPrimary),
      toolbarHeight: 56,
    ),
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.elevated,
      selectedColor: AppColors.elevated,
      checkmarkColor: AppColors.primary,
      labelStyle: const TextStyle(
        color: AppColors.textSecondary,
        fontSize: 11,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.6,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: AppColors.borderStrong),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      side: BorderSide.none,
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: AppColors.elevated,
      contentTextStyle: TextStyle(color: AppColors.textPrimary, fontSize: 13),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(12)),
      ),
      behavior: SnackBarBehavior.floating,
      elevation: 6,
    ),
  );
}
