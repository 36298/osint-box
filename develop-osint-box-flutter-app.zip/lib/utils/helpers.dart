/// Shared validation & formatting utilities for all OSINT modules.
library;

/// Normalizes user input to a bare hostname (lowercased, no path/query/strip).
String normalizeDomain(String input) {
  var s = input.trim().toLowerCase();
  if (s.isEmpty) return s;
  if (!s.startsWith('http://') && !s.startsWith('https://')) {
    s = 'https://$s';
  }
  try {
    final uri = Uri.parse(s);
    var host = uri.host;
    if (host.isEmpty) {
      final stripped = s.replaceFirst(RegExp(r'^https?://'), '');
      host = stripped.split('/').first;
    }
    return host;
  } catch (_) {
    final stripped = s.replaceFirst(RegExp(r'^https?://'), '');
    return stripped.split('/').first;
  }
}

/// RFC-1035-aware domain validation (labels, TLD, length).
bool isValidDomain(String domain) {
  if (domain.isEmpty || domain.length > 253) return false;
  final regex = RegExp(
    r'^(?=.{1,253}\.?$)(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))*\.[a-z]{2,63}\.?$',
    caseSensitive: false,
  );
  return regex.hasMatch(domain);
}

/// Username validation for social/developer platforms.
bool isValidUsername(String username) {
  if (username.isEmpty || username.length > 40) return false;
  return RegExp(r'^[A-Za-z0-9][A-Za-z0-9._-]*$').hasMatch(username);
}

/// Extracts a safe list of ints from a dynamic JSON value.
double? toDouble(dynamic v) {
  if (v == null) return null;
  if (v is double) return v;
  if (v is int) return v.toDouble();
  if (v is String) return double.tryParse(v);
  return null;
}

/// Converts an ISO 8601-ish date/time string into a controlled format.
String formatDate(String? iso) {
  if (iso == null || iso.trim().isEmpty) return '—';
  try {
    final d = DateTime.parse(iso);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  } catch (_) {
    return iso;
  }
}

/// Age badge for expiration dates.
bool isPast(String? iso) {
  if (iso == null || iso.trim().isEmpty) return false;
  try {
    final d = DateTime.parse(iso);
    final now = DateTime.now();
    return d.isBefore(now);
  } catch (_) {
    return false;
  }
}

/// Safe string coercion.
String? safeString(dynamic v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

/// Reads a value from a list of candidate keys, newest-wins.
T? pick<T>(Map<String, dynamic> source, List<String> keys, T Function(dynamic) convert) {
  for (final k in keys) {
    final v = source[k];
    if (v != null) {
      try {
        final r = convert(v);
        if (r != null) return r;
      } catch (_) {}
    }
  }
  return null;
}
