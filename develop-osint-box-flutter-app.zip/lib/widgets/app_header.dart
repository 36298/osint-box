import 'package:flutter/material.dart';

import 'package:osint_box/theme.dart';

/// Module header: back button, icon chip, title + subtitle.
class AppHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Accent accent;
  final VoidCallback? onBack;

  const AppHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.accent = Accent.green,
    this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (onBack != null) ...[
            InkWell(
              onTap: onBack,
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: AppColors.elevated,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.border),
                ),
                child: const Icon(Icons.arrow_back, size: 18),
              ),
            ),
            const SizedBox(width: 12),
          ],
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: accent.tint,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: accent.strong),
            ),
            child: Icon(icon, color: accent.solid, size: 23),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
