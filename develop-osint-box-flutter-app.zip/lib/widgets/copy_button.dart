import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:osint_box/theme.dart';

/// One-tap "copy to clipboard" action.
class CopyButton extends StatelessWidget {
  final String text;
  final String label;
  final bool iconOnly;

  const CopyButton({
    super.key,
    required this.text,
    this.label = 'Copy',
    this.iconOnly = false,
  });

  Future<void> _copy(BuildContext context) async {
    try {
      await Clipboard.setData(ClipboardData(text: text));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Copied to clipboard'), duration: Duration(milliseconds: 1400)),
      );
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Copy failed')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final enabled = text.trim().isNotEmpty;
    if (iconOnly) {
      return IconButton(
        tooltip: 'Copy',
        visualDensity: VisualDensity.compact,
        icon: const Icon(Icons.content_copy, size: 15),
        color: enabled ? AppColors.textSecondary : AppColors.borderStrong,
        onPressed: enabled ? () => _copy(context) : null,
        constraints: const BoxConstraints(minWidth: 30, minHeight: 30),
        padding: EdgeInsets.zero,
      );
    }
    return OutlinedButton.icon(
      onPressed: enabled ? () => _copy(context) : null,
      icon: const Icon(Icons.content_copy, size: 14),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.textPrimary,
        side: const BorderSide(color: AppColors.borderStrong),
        backgroundColor: AppColors.elevated,
        minimumSize: const Size(0, 36),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
