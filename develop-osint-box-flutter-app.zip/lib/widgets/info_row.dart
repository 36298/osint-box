import 'package:flutter/material.dart';

import 'package:osint_box/theme.dart';

/// Key/value row used for every result screen.
class InfoRow extends StatelessWidget {
  final String label;
  final String? value;
  final bool mono;
  final IconData? valueIcon;
  final VoidCallback? onLongPress;

  const InfoRow({
    super.key,
    required this.label,
    this.value,
    this.mono = false,
    this.valueIcon,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final hasValue = value != null && value!.trim().isNotEmpty;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            child: Text(
              label.toUpperCase(),
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            flex: 3,
            child: GestureDetector(
              onLongPress: onLongPress,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (valueIcon != null && hasValue) ...[
                    Icon(valueIcon, size: 13, color: AppColors.textSecondary),
                    const SizedBox(width: 6),
                  ],
                  Flexible(
                    child: Text(
                      hasValue ? value! : '—',
                      textAlign: TextAlign.right,
                      maxLines: mono ? 1 : 4,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: mono ? 'monospace' : null,
                        color: hasValue
                            ? (mono ? AppColors.secondary : AppColors.textPrimary)
                            : AppColors.textSecondary,
                        fontSize: mono ? 12.5 : 13.5,
                        fontWeight: mono ? FontWeight.w700 : FontWeight.w600,
                        letterSpacing: mono ? 0.3 : 0.1,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
