import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share.dart';

import 'package:osint_box/theme.dart';

/// Copy / share / export-as-JSON actions shown under every result.
class JsonShareBar extends StatelessWidget {
  final Map<String, dynamic> json;
  final String subject;

  const JsonShareBar({super.key, required this.json, this.subject = 'OSINT Box export'});

  String get _encoded => const JsonEncoder.withIndent('  ').convert(json);

  Future<void> _copy(BuildContext context) async {
    try {
      await Clipboard.setData(ClipboardData(text: _encoded));
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('JSON copied to clipboard')),
      );
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Copy failed')),
      );
    }
  }

  Future<void> _share(BuildContext context) async {
    try {
      await Share.share(_encoded, subject: subject);
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Share is unavailable')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: json.isEmpty ? null : () => _copy(context),
              icon: const Icon(Icons.data_object, size: 15),
              label: const Text('Copy JSON'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.textPrimary,
                side: const BorderSide(color: AppColors.borderStrong),
                backgroundColor: AppColors.elevated,
                minimumSize: const Size(0, 40),
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: json.isEmpty ? null : () => _share(context),
              icon: const Icon(Icons.share, size: 15),
              label: const Text('Share'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(0, 40),
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
