import { useState } from "react";
import {
  Radar,
  Globe,
  Network,
  ShieldCheck,
  Landmark,
  User,
  KeyRound,
  Copy,
  ArrowRight,
  GitBranch,
  CheckCircle2,
  Terminal,
  FileText,
  Zap,
  Shield,
} from "lucide-react";

const workflowYaml = `name: Build Android APK

on:
  push:
    branches: [main, master]
  pull_request:
  workflow_dispatch:

jobs:
  build:
    name: Build release APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up Java JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Flutter (stable)
        uses: subosito/flutter-action@v2
        with:
          channel: stable
          cache: true

      - name: Scaffold Android project
        run: flutter create . --org com.osintbox --project-name osint_box --platforms android

      - name: Install dependencies
        run: flutter pub get

      - name: Build release APK
        run: flutter build apk --release

      - name: Upload release APK
        uses: actions/upload-artifact@v4
        with:
          name: OSINT-Box-release-APK
          path: build/app/outputs/flutter-apk/app-release.apk`;

const modules = [
  {
    icon: Globe,
    name: "IP Intelligence",
    desc: "Live geolocation, ASN, ISP, organization, timezone & coordinates via ipapi.co / ipwho.is with a “My IP” default.",
    accent: "#00E676",
    tag: "LIVE API",
  },
  {
    icon: Network,
    name: "DNS Recon",
    desc: "A / AAAA / MX / TXT / NS / CNAME records with TTL values through DNS-over-HTTPS (dns.google).",
    accent: "#00B0FF",
    tag: "DoH",
  },
  {
    icon: ShieldCheck,
    name: "HTTP Analyzer",
    desc: "Status codes, server banners, redirect chains and missing security headers (HSTS · CSP · XFO · XCTO) with a grade.",
    accent: "#C792EA",
    tag: "LIVE API",
  },
  {
    icon: Landmark,
    name: "RDAP Lookup",
    desc: "Registrar, registration/expiration dates, nameservers and status flags via rdap.org.",
    accent: "#FFC857",
    tag: "RDAP.ORG",
  },
  {
    icon: User,
    name: "Username Enumeration",
    desc: "Direct profile links for GitHub, Reddit, Keybase, X, Instagram, TikTok and Medium — one-tap browser launch.",
    accent: "#FF9F43",
    tag: "LIVE API",
  },
  {
    icon: KeyRound,
    name: "Crypto Tools",
    desc: "Offline MD5 / SHA-1 / SHA-256 / SHA-512 / bcrypt detection and Base64 / URL / hex encodings. Nothing leaves the device.",
    accent: "#FF5252",
    tag: "OFFLINE",
  },
];

const pipeline = [
  { n: "01", title: "Checkout", desc: "actions/checkout@v4" },
  { n: "02", title: "Java 17", desc: "actions/setup-java@v4" },
  { n: "03", title: "Flutter stable", desc: "subosito/flutter-action@v2" },
  { n: "04", title: "Scaffold + manifest", desc: "flutter create + INTERNET & queries" },
  { n: "05", title: "pub get + build", desc: "flutter build apk --release" },
  { n: "06", title: "Artifact", desc: "actions/upload-artifact@v4" },
];

export default function App() {
  const [copied, setCopied] = useState(false);

  const copyWorkflow = async () => {
    try {
      await navigator.clipboard.writeText(workflowYaml);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="min-h-screen bg-ink text-tx relative overflow-hidden">
      {/* background layers */}
      <div className="absolute inset-0 grid-bg" />
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full bg-neon/10 blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 -right-40 w-[500px] h-[500px] rounded-full bg-neon-2/10 blur-[140px] pointer-events-none" />

      {/* navbar */}
      <header className="relative z-10 border-b border-line/70 backdrop-blur-md bg-ink/70 sticky top-0">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-neon/15 border border-neon/40 flex items-center justify-center">
              <Radar size={18} className="text-neon" />
            </div>
            <div className="font-bold tracking-[0.3em] text-sm">OSINT BOX</div>
            <span className="text-[10px] px-2 py-0.5 rounded-md border border-line text-tx-2 tracking-widest hidden sm:inline-block">
              v1.0.0
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] tracking-widest text-tx-2">
            <span className="hidden md:inline px-2 py-1 rounded-md border border-line">FLUTTER</span>
            <span className="hidden md:inline px-2 py-1 rounded-md border border-line">ANDROID</span>
            <a
              href="https://github.com/marketplace"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-neon text-[#04170a] font-bold hover:brightness-110 transition"
            >
              <GitBranch size={14} /> GITHUB ACTIONS
            </a>
          </div>
        </div>
      </header>

      {/* hero */}
      <main className="relative z-10">
        <section className="max-w-6xl mx-auto px-6 pt-20 pb-16 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-neon/40 bg-neon/10 text-neon text-[10.5px] font-bold tracking-[0.25em] mb-8">
            <Zap size={12} /> LOCAL-FIRST RECONNAISSANCE TOOLKIT
          </div>
          <h1 className="text-5xl sm:text-7xl font-black tracking-tight leading-[1.05]">
            OSINT BOX
            <br />
            <span className="text-neon glow-green font-black">IS BUILT.</span>
          </h1>
          <p className="max-w-2xl mx-auto mt-6 text-tx-2 text-[15px] sm:text-base leading-relaxed">
            A production-ready Android app — live IP intelligence, DNS-over-HTTPS records,
            HTTP security header analysis, RDAP lookups, username enumeration and fully
            offline crypto — compiled and shipped through GitHub Actions with a single pipeline.
          </p>
          <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#modules" className="group flex items-center gap-2 bg-neon text-[#04170a] font-extrabold px-7 py-3.5 rounded-xl text-sm tracking-wide shadow-[0_0_40px_-8px_rgba(0,230,118,0.55)] hover:brightness-110 transition">
              EXPLORE MODULES
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#workflow" className="group flex items-center gap-2 border border-line-2 text-tx font-bold px-7 py-3.5 rounded-xl text-sm tracking-wide hover:border-neon/50 hover:text-neon transition">
              <Terminal size={15} /> SEE THE WORKFLOW
            </a>
          </div>
          <div className="mt-12 grid grid-cols-3 gap-3 max-w-xl mx-auto">
            {[
              { v: "6", l: "modules" },
              { v: "5+", l: "public sources" },
              { v: "0", l: "API keys / accounts" },
            ].map((s) => (
              <div key={s.l} className="rounded-xl border border-line bg-ink-2/70 px-2 py-4">
                <div className="text-2xl font-black text-tx">{s.v}</div>
                <div className="text-[10px] tracking-[0.2em] text-tx-2 mt-1">{s.l.toUpperCase()}</div>
              </div>
            ))}
          </div>
        </section>

        {/* modules */}
        <section id="modules" className="max-w-6xl mx-auto px-6 pb-20">
          <SectionLabel text="MODULE MATRIX" accent="modules" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {modules.map((m) => (
              <div
                key={m.name}
                className="card-glow group rounded-2xl border border-line bg-ink-2/80 p-6 hover:border-line-2 hover:-translate-y-1 transition-all duration-300"
              >
                <div className="flex items-start justify-between">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center border"
                    style={{
                      background: `${m.accent}1f`,
                      borderColor: `${m.accent}40`,
                    }}
                  >
                    <m.icon size={22} style={{ color: m.accent }} />
                  </div>
                  <span
                    className="text-[9px] font-extrabold tracking-[0.2em] px-2 py-1 rounded-md border"
                    style={{ color: m.accent, borderColor: `${m.accent}44`, background: `${m.accent}14` }}
                  >
                    {m.tag}
                  </span>
                </div>
                <h3 className="mt-4 text-lg font-extrabold tracking-tight">{m.name}</h3>
                <p className="mt-2 text-[12.5px] leading-relaxed text-tx-2">{m.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* pipeline */}
        <section className="max-w-6xl mx-auto px-6 pb-20">
          <SectionLabel text="PIPELINE" accent="workflow" />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {pipeline.map((p) => (
              <div key={p.n} className="rounded-xl border border-line bg-ink-2/70 p-5 flex gap-3 items-start">
                <span className="text-[10px] font-black text-neon tracking-widest mt-0.5">{p.n}</span>
                <div>
                  <div className="text-sm font-bold tracking-tight">{p.title}</div>
                  <div className="text-[11px] text-tx-2 mt-1 leading-snug">{p.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* workflow file */}
        <section id="workflow" className="max-w-6xl mx-auto px-6 pb-24">
          <SectionLabel text="WORKFLOW" accent="build.yml" />
          <div className="rounded-2xl border border-line bg-ink-2/80 overflow-hidden card-glow">
            <div className="flex items-center justify-between px-5 py-3 border-b border-line bg-ink-3/60">
              <div className="flex items-center gap-2 text-[11px] tracking-widest text-tx-2">
                <FileText size={13} className="text-neon" /> .github/workflows/build.yml
              </div>
              <button
                onClick={copyWorkflow}
                className="flex items-center gap-1.5 text-[11px] font-bold tracking-wider text-neon hover:brightness-125 transition"
              >
                {copied ? (
                  <>
                    <CheckCircle2 size={13} /> COPIED
                  </>
                ) : (
                  <>
                    <Copy size={13} /> COPY
                  </>
                )}
              </button>
            </div>
            <pre className="text-[11.5px] leading-relaxed p-5 overflow-x-auto text-[#c9d4e0]">
              {workflowYaml}
            </pre>
          </div>
          <p className="mt-4 text-[11px] text-tx-2 flex items-start gap-2 leading-relaxed">
            <CheckCircle2 size={14} className="text-neon shrink-0 mt-0.5" />
            <span>
              Push this repository to GitHub and it builds itself — Java 17, Flutter stable,
              <code className="px-1.5 py-0.5 rounded bg-ink-3 border border-line text-neon mx-1">flutter pub get</code>,
              <code className="px-1.5 py-0.5 rounded bg-ink-3 border border-line text-neon mx-1">flutter build apk --release</code>
              and the APK lands as a downloadable artifact — zero local Android setup. The manifest also auto-configures
              INTERNET + visibility queries for Android 11+.
            </span>
          </p>
        </section>
      </main>

      {/* footer */}
      <footer className="relative z-10 border-t border-line/70 bg-ink-2/50">
        <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] tracking-widest text-tx-2">
          <div className="flex items-center gap-2">
            <Radar size={14} className="text-neon" />
            OSINT BOX · BUILD PIPELINE READY
          </div>
          <div className="flex items-center gap-2">
            <Shield size={13} className="text-neon" />
            INTERNET · QUERIES · NO KEYS · NO ACCOUNTS
          </div>
        </div>
      </footer>
    </div>
  );
}

function SectionLabel({ text, accent }: { text: string; accent: string }) {
  return (
    <div className="flex items-center gap-3 mb-6">
      <div className="w-1.5 h-1.5 rounded-full bg-neon" />
      <span className="text-[11px] font-extrabold tracking-[0.35em] text-tx-2">{text}</span>
      <div className="flex-1 h-px bg-line" />
      <span className="text-[10px] text-tx-2 tracking-widest hidden sm:block">{accent.toUpperCase()}</span>
    </div>
  );
}
